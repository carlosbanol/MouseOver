﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MouseOver
{
    public partial class Form1 : Form
    {
        private Random random = new Random();
        private Timer timer;
        private Point origen;
        public Form1()
        {
            InitializeComponent();
    }

        private void click_enter(object sender, EventArgs e)
        {
            //System.Timers.Timer timer = new System.Timers.Timer();
            origen = btn_mover.Location;
            timer = new Timer();

            timer.Interval = 10;
            timer.Tick += AnimationTimer_Tick;
            timer.Start();
        }

        private void btn_leave(object sender, EventArgs e)
        {
            timer.Stop();
            btn_mover.Location = origen;
        }

        private void AnimationTimer_Tick(object sender, EventArgs e)
        {
            // Generar una nueva posición aleatoria dentro de los límites de la forma
            int newX = random.Next(this.ClientSize.Width - btn_mover.Width);
            int newY = random.Next(this.ClientSize.Height - btn_mover.Height);

            // Mover el botón a la nueva posición
            btn_mover.Location = new Point(newX, newY);
        }
    }
}
